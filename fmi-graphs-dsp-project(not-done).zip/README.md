Graph Store

Console tool for work with "graphs", adding and deleting nodes, finding paths... and... other stuff: https://docs.google.com/document/d/1YdsD55n3ssXoV16THYLwU4STKc3kp5HnIQsLrOkNGUM/edit
